create database chang;
use chang;
create table chang1 (id int);
